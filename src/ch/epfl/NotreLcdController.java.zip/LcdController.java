package ch.epfl.gameboj.component.lcd;

import ch.epfl.gameboj.*;
import ch.epfl.gameboj.bits.Bit;
import ch.epfl.gameboj.bits.BitVector;
import ch.epfl.gameboj.bits.Bits;
import ch.epfl.gameboj.component.Clocked;
import ch.epfl.gameboj.component.Component;
import ch.epfl.gameboj.component.cpu.Cpu;
import ch.epfl.gameboj.component.memory.Ram;

import java.util.Arrays;
import java.util.Objects;

/**
 * Represents a Lcd controller
 *
 * @author Lucie Hoffmann (286865)
 * @author Marie Jaillot (270130)
 */
public final class LcdController implements Component, Clocked {

    public static final int LCD_WIDTH = 160;
    public static final int LCD_HEIGHT = 144;
    private static final int MODE2_DURATION = 20;
    private static final int MODE3_DURATION = 43;
    private static final int MODE0_DURATION = 51;
    private static final int MODE1_DURATION = 1140;
    private static final int BG_SIZE = 32, BG_PIXEL_SIZE = 256;
    private static final int WIN_SIZE = 20;
    private static final int TILE_SIZE = 8, BIG_TILE_HEIGHT = 16;
    private static final int NUMBER_OF_SPRITES = 40;
    private static final int MAX_SPRITES_PER_LINE = 10;
    private static final int SPRITE_ATTRIBUTES_SIZE = 4;
    private static final int SPRITE_X_COORDINATE_INDEX = 1;
    private static final int SPRITE_TILE_INDEX = 2;
    private static final int SPRITE_CARACTERISICS_INDEX = 3;
    private static final int BEHIND_BG_INDEX = 7;
    private static final int PALETTE_INDEX = 4;
    private static final int TILE_SHIFT_INDEX = 0x80;
    private static final int SET_WX = 7;
    private static final int LCDC_ADDRESS = 0xFF40, STAT_ADDRESS = 0xFF41,
            SCY_ADDRESS = 0xFF42, SCX_ADDRESS = 0xFF43, LY_ADDRESS = 0xFF44,
            LYC_ADDRESS = 0xFF45, DMA_ADDRESS = 0xFF46, BGPAddress = 0xFF47,
            OBP_0_ADDRESS = 0xFF48, OBP_1_ADDRESS = 0xFF49, WY_ADDRESS = 0xFF4A,
            WX_ADDRESS = 0xFF4B;
    private static final int FLIP_H_INDEX = 5;
    private static final int FLIP_V_INDEX = 6;
    private Cpu cpu;
    private Ram videoRam;
    private Ram oam;
    private Bus bus;
    private LcdImage.Builder nextImageBuilder;
    private long nextNonIdleCycle;
    private int winY;
    private LcdImage currentImage;
    private int copyIndex;

    // NIZAR
    private Mode lastMode = Mode.M0;
    private long lastImageCycle = 0;

    private static final RegisterFile<Reg> regFile = new RegisterFile<>(
            Reg.values());

    /**
     * LCD controller's 8 bits registers
     */
    private enum Reg implements Register {
        LCDC, STAT, SCY, SCX, LY, LYC, DMA, BGP, OBP0, OBP1, WY, WX
    }

    private enum LCDCBits implements Bit {
        BG, OBJ, OBJ_SIZE, BG_AREA, TILE_SOURCE, WIN, WIN_AREA, LCD_STATUS
    }

    private enum STATBits implements Bit {
        MODE0, MODE1, LYC_EQ_LY, INT_MODE0, INT_MODE1, INT_MODE2, INT_LYC
    }

    private enum Mode {
        M0, M1, M2, M3
    }


    /**
     * Constructs an lcd controller belonging to the given cpu.
     *
     * @param cpu Cpu that is going to contain the lcd controller in construction
     */
    public LcdController(Cpu cpu) {
        this.cpu = cpu;
        videoRam = new Ram(AddressMap.VIDEO_RAM_SIZE);
        oam = new Ram(AddressMap.OAM_RAM_SIZE);
        nextImageBuilder = new LcdImage.Builder(LCD_WIDTH, LCD_HEIGHT);
        currentImage = new LcdImage.Builder(LCD_WIDTH, LCD_HEIGHT).build();
        nextNonIdleCycle = Long.MAX_VALUE;
        winY = 0;
    }

    @Override public void cycle(long cycle) {
        assert (cycle
                <= nextNonIdleCycle) : "Current cycle is bigger than nextNonIdleCycle";

        if (nextNonIdleCycle == Long.MAX_VALUE && regFile
                .testBit(Reg.LCDC, LCDCBits.LCD_STATUS))
        // gestion allumage de l'écran : allumage
        {
            setMode(Mode.M2);
            nextNonIdleCycle = cycle;
            reallyCycle();
        }

        if (copyIndex < 160) {
            oam.write(copyIndex,
                    bus.read(Bits.make16(regFile.get(Reg.DMA), copyIndex)));
            copyIndex += 1;
            //nextNonIdleCycle += 1;
        }

        if (cycle == nextNonIdleCycle && regFile
                .testBit(Reg.LCDC, LCDCBits.LCD_STATUS))
            reallyCycle();
    }

    private void reallyCycle() {
        long cycle = nextNonIdleCycle;
        long cycleOnWakeUp = cycle % (114 * 154);
        long cycleMode = nextNonIdleCycle - cycleOnWakeUp;
        int lineIndex = (int) (cycleMode / 114) % 154;
        switch (getMode(cycleMode)) {
        case M0: {
            nextNonIdleCycle += 51;
            setMode(Mode.M0);
            //System.out.println("Cycle: " + cycle + " since frame: " + (cycle - lastImageCycle) + "  | MODE: " + lastMode.ordinal() + "  --> 0");
            lastMode = Mode.M0;
            if (regFile.testBit(Reg.STAT, STATBits.INT_MODE0)) {
                //System.out.println("Cycle: " + cycle + " since frame: " + (cycle - lastImageCycle) + "  |  request interrupt LCD_STAT");
                cpu.requestInterrupt(Cpu.Interrupt.LCD_STAT);
            }

        }
        break;
        case M1: {
            nextNonIdleCycle += 114;
            //TODO delete this if statement
			/*if(lastMode != LcdMode.MODE1)
				System.out.println("Cycle: " + cycle + " since frame: " + (cycle - lastImageCycle) + "  | MODE: " + lastMode.ordinal() + "  --> 1");*/
            setMode(Mode.M1);
            lastMode = Mode.M1;
            if (lineIndex == 144) {
                cpu.requestInterrupt(Cpu.Interrupt.VBLANK);
                //System.out.println("Cycle: " + cycle + " since frame: " + (cycle - lastImageCycle) + "  |  request interrupt VBLANK");
            }
            modifLY_LYC(Reg.LY, lineIndex);
            //System.out.println("Cycle: " + cycle + " since frame: " + (cycle - lastImageCycle) + "  |  LY: " + lastIndex + " --> " + lineIndex);
            if (regFile.testBit(Reg.STAT, STATBits.INT_MODE1)) {
                cpu.requestInterrupt(Cpu.Interrupt.LCD_STAT);
                //System.out.println("Cycle: " + cycle + " since frame: " + (cycle - lastImageCycle) + "  |  request interrupt LCD_STAT");

            }
        }
        break;
        case M2: {
            nextNonIdleCycle += 20;
            if(lineIndex == 0) {
                lastImageCycle = cycle;
                currentImage = nextImageBuilder.build();
                nextImageBuilder = new LcdImage.Builder(LCD_WIDTH, LCD_HEIGHT);
                winY = 0;
            }
            setMode(Mode.M2);
            //System.out.println("Cycle: " + cycle + " since frame: " + (cycle - lastImageCycle) + "  | MODE: " + lastMode.ordinal() + "  --> 2");
            lastMode = Mode.M2;
            if (regFile.testBit(Reg.STAT, STATBits.INT_MODE2)) {
                cpu.requestInterrupt(Cpu.Interrupt.LCD_STAT);
                //System.out.println("Cycle: " + cycle + " since frame: " + (cycle - lastImageCycle) + "  |  request interrupt LCD_STAT");

            }
            modifLY_LYC(Reg.LY, lineIndex);
            //System.out.println("Cycle: " + cycle + " since frame: " + (cycle - lastImageCycle) + "  |  LY: " + lastIndex + " --> " + lineIndex);

        }
        break;
        case M3: {
            nextNonIdleCycle += 43;
            nextImageBuilder.setLine(lineIndex, computeLine(lineIndex));
            setMode(Mode.M3);
            //System.out.println("Cycle: " + cycle + " since frame: " + (cycle - lastImageCycle) + "  | MODE: " + lastMode.ordinal() + "  --> 3");
            lastMode = Mode.M3;
        }
        break;
        }
    }

    /*private void reallyCycle() {
        int currentLine = regFile.get(Reg.LY);
        System.out.print("cycles: " + nextNonIdleCycle + "   since frame: " + nextNonIdleCycle % 256 + "    ");
        switch (getMode()) {
        // MODE 0
        case M0: {
            nextNonIdleCycle += MODE0_DURATION;
            if (regFile.testBit(Reg.STAT, STATBits.INT_MODE0)) {
                cpu.requestInterrupt(Cpu.Interrupt.LCD_STAT);
            }
            //System.out.println("LY : " + regFile.get(Reg.LY));

            // ici nizar set mode 0 sans condition, pas mode 1 ni 2 ni modif LY
            if (currentLine >= 142) {// Changement D'Amro dont le code marche, mais j'ai vu ca nul part ( dans piazza si)
                System.out.println(" mode : " + getMode().ordinal() + " --> ");
                setMode(Mode.M1);

            }
            else {
                setMode(Mode.M2);
                //System.out.println(" mode :" + getMode().ordinal() + " --> ");
            }
            modifLY_LYC(Reg.LY, currentLine + 1);
        }
        break;

        // MODE 1
        case M1: {
            currentImage = nextImageBuilder.build(); // construction image debut mode 1 d'apres enoncé (si bien compris...)

            // nizar lance en 144 lui
            if (currentLine == LCD_HEIGHT - 1) { // Interruption lancée en 143 au lieu de 144 d'après Amro et piazza
                cpu.requestInterrupt(Cpu.Interrupt.VBLANK);
                System.out.println(" request VBLANK interrupt ");
                //System.out.println("VBLANK : " + nextNonIdleCycle + "  " + (nextNonIdleCycle-17556));
            }

            nextNonIdleCycle += MODE1_DURATION;

            if (regFile.testBit(Reg.STAT, STATBits.INT_MODE1))
                cpu.requestInterrupt(Cpu.Interrupt.LCD_STAT);

            // gestion differente de LY chez nizar et set mode 1 sans condition seulement
            if (currentLine < 153) {
                System.out.print(" mode : " + getMode().ordinal() + " --> ");
                setMode(Mode.M1);
                modifLY_LYC(Reg.LY, currentLine + 1);
            } else {
                //currentImage = nextImageBuilder.build();
                System.out.print(" mode : " + getMode().ordinal() + " --> ");
                setMode(Mode.M2);
                modifLY_LYC(Reg.LY, 0);
                //System.out.println("LY : " + regFile.get(Reg.LY));
            }
        }
        break;

        // MODE 2
        case M2: {
            nextNonIdleCycle += MODE2_DURATION;
            if (regFile.testBit(Reg.STAT, STATBits.INT_MODE2))
                cpu.requestInterrupt(Cpu.Interrupt.LCD_STAT);

            // nizar set en mode 2 seulement
            System.out.print(" mode : " + getMode().ordinal() + " --> ");
            setMode(Mode.M3);

            if (regFile.get(Reg.LY) == 0) {
                // nizar construit l'image ici lui
                nextImageBuilder = new LcdImage.Builder(LCD_WIDTH,
                        LCD_HEIGHT); // nouveau bâtisseur stocké dans attribut lors passage en mode 2 pour 1ere ligne
                winY = 0;
            }
        }
        break;

        // MODE 3
        case M3: {
            nextNonIdleCycle += MODE3_DURATION;

            // nizar set mode 3 et pas 0
            System.out.print(" mode : " + getMode().ordinal() + " --> ");
            setMode(Mode.M0);
            nextImageBuilder.setLine(currentLine, computeLine(currentLine));
        }
        break;
        }
    }*/

    @Override public void attachTo(Bus bus) {
        this.bus = bus;
        Component.super.attachTo(bus);
    }

    private Mode getMode(long cycle) {
        long step = cycle % 114;
        int lineIndex = (int) (cycle / 114) % 154;
        if (lineIndex >= LCD_HEIGHT)
            return Mode.M1;
        else if (step < 20 && step >= 0)
            return Mode.M2;
        else if (step < 63 && step >= 20)
            return Mode.M3;
        else
            return Mode.M0;
    }

    /*private Mode getMode() {
        int statValue = regFile.get(Reg.STAT);
        int mode = Bits.clip(2, statValue);
        //System.out.print(" mode :  " + mode + " --> ");

        return Mode.values()[mode];
    }*/

    private void setMode(Mode mode) {
        regFile.setBit(Reg.STAT, STATBits.MODE0, Bits.test(mode.ordinal(), 0));
        regFile.setBit(Reg.STAT, STATBits.MODE1, Bits.test(mode.ordinal(), 1));
       // System.out.println(mode.ordinal());
    }

    @Override public int read(int address) {
        Preconditions.checkBits16(address);

        if (AddressMap.VIDEO_RAM_START <= address
                && address < AddressMap.VIDEO_RAM_END)
            return videoRam.read(address - AddressMap.VIDEO_RAM_START);

        if (AddressMap.OAM_START <= address && address < AddressMap.OAM_END)
            return oam.read(address - AddressMap.OAM_START);

        if (AddressMap.REGS_LCDC_START <= address
                && address < AddressMap.REGS_LCDC_END) {
            Reg r = Reg.values()[address - AddressMap.REGS_LCDC_START];

            return regFile.get(r);
        }
        return NO_DATA;
    }

    @Override public void write(int address, int data) {
        Preconditions.checkBits16(address);
        Preconditions.checkBits8(data);

        /*boolean extinction = !Bits.test(data, 7);*/
        boolean extinction = !regFile.testBit(Reg.LCDC, LCDCBits.LCD_STATUS);

        if (AddressMap.VIDEO_RAM_START <= address
                && address < AddressMap.VIDEO_RAM_END)
            videoRam.write(address - AddressMap.VIDEO_RAM_START, data);

        else if (AddressMap.OAM_START <= address
                && address < AddressMap.OAM_END)
            oam.write(address - AddressMap.OAM_START, data);

        else if (AddressMap.REGS_LCDC_START <= address
                && address < AddressMap.REGS_LCDC_END) {
            Reg r = Reg.values()[address - AddressMap.REGS_LCDC_START];

            switch (address) {
            case LCDC_ADDRESS:
                regFile.set(Reg.LCDC, data);
                if (extinction) {
                    // passage de LCD en mode 0
                    setMode(Mode.M0);
                    //LY --> 0
                    modifLY_LYC(Reg.LY, 0);
                    nextNonIdleCycle = Long.MAX_VALUE;
                }
                break;
            case STAT_ADDRESS:
                int lsbSTAT = Bits.clip(3, regFile.get(Reg.STAT));
                int masklsb = 0b1111_1000; // ici changement
                int realData = data & masklsb;
                regFile.set(Reg.STAT, lsbSTAT | realData);
                break;
            case LY_ADDRESS:
                break;
            case LYC_ADDRESS:
                modifLY_LYC(Reg.LYC, data);
                break;
            case DMA_ADDRESS:
                regFile.set(Reg.DMA, data);
                copyIndex = 0;
                break;
            default:
                regFile.set(r, data);
            }
        }
    }

    private void modifLY_LYC(Reg LYorLYC, int data) {
        regFile.set(LYorLYC, data);

        // TEST
        /*if (LYorLYC == Reg.LY)
            System.out.println("                         LY : " + regFile.get(Reg.LY));
        //*/

        regFile.setBit(Reg.STAT, STATBits.LYC_EQ_LY, regFile.get(Reg.LY) == regFile.get(Reg.LYC));

        if (regFile.testBit(Reg.STAT, STATBits.INT_LYC))
            cpu.requestInterrupt(Cpu.Interrupt.LCD_STAT);
    }

    /**
     * Returns the image currently displayed on the screen.
     *
     * @return LcdImage, the image currently displayed on the screen
     */
    public LcdImage currentImage() {
        // retourne toujours une image non nulle de 160×144 pixels
        return currentImage;
    }

    private LcdImageLine computeLine(int indexLine) {
        Objects.checkIndex(indexLine, LCD_HEIGHT);
        int lineToCompute = (indexLine + regFile.get(Reg.SCY)) % BG_PIXEL_SIZE;

        LcdImageLine bgLine = new LcdImageLine.Builder(BG_PIXEL_SIZE)
                .build();

        boolean drawBg = regFile.testBit(Reg.LCDC, LCDCBits.BG);
        int wy = regFile.get(Reg.WY);
        int wx = regFile.get(Reg.WX) - SET_WX;
        boolean drawWin = regFile.testBit(Reg.LCDC, LCDCBits.WIN) && 0 <= wx && wx < LCD_WIDTH;
        int palette = read(BGPAddress);
        boolean drawSprite = regFile.testBit(Reg.LCDC, LCDCBits.OBJ);

        //======================================================================
        // Background drawing

        if (drawBg) {
            int plageBg = regFile.testBit(Reg.LCDC, LCDCBits.BG_AREA) ?
                    AddressMap.BG_DISPLAY_DATA[1] :
                    AddressMap.BG_DISPLAY_DATA[0];
            bgLine = constructFromTiles(BG_SIZE, plageBg, lineToCompute)
                    .extractWrapped(regFile.get(Reg.SCX), LCD_WIDTH);
        }

        //======================================================================
        // Window drawing

        if (drawWin) {
            int plageWin = regFile.testBit(Reg.LCDC, LCDCBits.WIN_AREA) ?
                    AddressMap.BG_DISPLAY_DATA[1] :
                    AddressMap.BG_DISPLAY_DATA[0];

            int actualWinLine = indexLine - wy;
            LcdImageLine winLine = constructFromTiles(WIN_SIZE, plageWin, actualWinLine).shift(wx).mapColors(palette);
            if (actualWinLine >= 0) {
                //System.out.println("lineWin");
                bgLine = bgLine.join(winLine, wx);
                winY += 1;
            }
        }

        LcdImageLine allLines = bgLine;

        //======================================================================
        // calcul ligne sprites arriere et avant plan
        if (drawSprite) {
            LcdImageLine spritesLineBG = new LcdImageLine.Builder(LCD_WIDTH).build();
            LcdImageLine spritesLineFront = new LcdImageLine.Builder(LCD_WIDTH).build();

            int[] spritesTable = spritesIntersectingLine(lineToCompute);

            for (int spriteIndex : spritesTable) {
                int spriteCaracteristics = oam.read(SPRITE_CARACTERISICS_INDEX
                        + spriteIndex * SPRITE_ATTRIBUTES_SIZE);
                boolean BEHIND_BG = Bits.test(spriteCaracteristics, BEHIND_BG_INDEX);
                boolean PALETTE = Bits.test(spriteCaracteristics, PALETTE_INDEX);
                boolean FLIP_H = Bits.test(spriteCaracteristics, FLIP_H_INDEX);
                boolean FLIP_V = Bits.test(spriteCaracteristics, FLIP_V_INDEX);
                int spriteHeight = regFile.testBit(Reg.LCDC, LCDCBits.OBJ_SIZE) ?
                        BIG_TILE_HEIGHT : TILE_SIZE;
                // GESTION FLIPS ???

                //method separee
                LcdImageLine.Builder spriteLineBuilder = new LcdImageLine.Builder(LCD_WIDTH);
                int indexTile = oam.read(SPRITE_TILE_INDEX + spriteIndex * SPRITE_ATTRIBUTES_SIZE);
                int coordX = oam.read(SPRITE_X_COORDINATE_INDEX
                        + spriteIndex * SPRITE_ATTRIBUTES_SIZE) - TILE_SIZE;
                int spriteMSB = Bits.reverse8(read(AddressMap.TILE_SOURCE[1] + indexTile + 1));
                int spriteLSB = Bits.reverse8(read(AddressMap.TILE_SOURCE[1] + indexTile));

                spriteLineBuilder.setBytes(0, spriteMSB, spriteLSB);// A faire dans une methode separee car similaire pour fenetre et BG d'apres enonce
                int paletteToUse = PALETTE ? regFile.get(Reg.OBP1) : regFile.get(Reg.OBP0);
                LcdImageLine oneSpriteLine = spriteLineBuilder.build().shift(coordX).mapColors(paletteToUse);

                if (BEHIND_BG)
                    oneSpriteLine.below(spritesLineBG);
                else
                    oneSpriteLine.below(spritesLineFront);
            }

            //======================================================================
            // transparence ou non du BG en fonction de l'opacité des sprites BG

            /*BitVector opacity = spritesLineBG.getOpacity()
                    .and(bgLine.getOpacity().not());*/
            BitVector opacity = spritesLineBG.getOpacity().not().or(bgLine.getOpacity());
            /*LcdImageLine bgLineAndSpritesBg = bgLine.below(spritesLineBG, opacity);*/
            LcdImageLine bgLineAndSpritesBg = spritesLineBG.below(bgLine, opacity);

            allLines = bgLineAndSpritesBg.below(spritesLineFront);
        }
        return allLines;
    }

    private LcdImageLine constructFromTiles(int size, int plage,
            int indexLine) {
        LcdImageLine.Builder currentLineBuilder = new LcdImageLine.Builder(
                size * TILE_SIZE);

        int indexLineTile = indexLine / TILE_SIZE;
        int indexLineInTile = indexLine % TILE_SIZE;

        int plageTile = regFile.testBit(Reg.LCDC, LCDCBits.TILE_SOURCE) ?
                AddressMap.TILE_SOURCE[1] :
                AddressMap.TILE_SOURCE[0];

        for (int column = 0; column < size; ++column) {
            int indexTile = read(plage + column + indexLineTile * BG_SIZE);

            if (plageTile == AddressMap.TILE_SOURCE[0])
                indexTile = indexTile < TILE_SHIFT_INDEX ?
                        indexTile + TILE_SHIFT_INDEX :
                        indexTile - TILE_SHIFT_INDEX;

            int addressBytes = plageTile + indexTile * 16 + indexLineInTile * 2;
            int LSB8 = read(addressBytes);
            int MSB8 = read(addressBytes + 1);
            currentLineBuilder
                    .setBytes(column, Bits.reverse8(MSB8), Bits.reverse8(LSB8));
        }

        /*// extraction par enroulement pour obtenir ligne de 20 bytes
        // (image affichée : 160×144 pixels au lieu de 256x256)
        LcdImageLine currentLine = currentLineBuilder.build().extractWrapped(regFile.get(Reg.SCX), LCD_WIDTH);
        // application de palette :
        int palette = read(BGPAddress);
        currentLine.mapColors(palette);

        return currentLine;*/
        return currentLineBuilder.build();
    }

    private int[] spritesIntersectingLine(int currentLine) {
        int spriteHeight = regFile.testBit(Reg.LCDC, LCDCBits.OBJ_SIZE) ?
                BIG_TILE_HEIGHT : TILE_SIZE;
        int[] infoSprites = new int[MAX_SPRITES_PER_LINE];
        int nbSprite = 0;

        for (int i = 0; i < NUMBER_OF_SPRITES; ++i) {
            int coordY = oam.read(i * SPRITE_ATTRIBUTES_SIZE) - BIG_TILE_HEIGHT;
            int coordX = oam.read(1 + i * SPRITE_ATTRIBUTES_SIZE) - TILE_SIZE;
            boolean spriteInLine = coordY <= currentLine && currentLine < coordY + spriteHeight;

            if (nbSprite < 10 && spriteInLine) {
                    infoSprites[nbSprite] = Bits.make16(coordX, i);
                    nbSprite += 1;
            }
        }

        Arrays.sort(infoSprites, 0, nbSprite);
        //System.out.println("nbSpriteLine : " + nbSprite);
        int[] indexSprite = new int[nbSprite];
        for (int i = 0; i < nbSprite; ++i)
            indexSprite[i] = Bits.clip(8, infoSprites[i]);

        return indexSprite;
    }
}